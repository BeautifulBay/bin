# From https://github.com/tpope/vim-pathogen with .vim replaced with vimfiles
mkdir -p ~/vimfiles/autoload ~/vimfiles/bundle; \
curl -so ~/vimfiles/autoload/pathogen.vim \
    https://raw.github.com/tpope/vim-pathogen/HEAD/autoload/pathogen.vim

# Install some plugins
cd ~/vimfiles/bundle
git clone git://github.com/scrooloose/nerdtree.git
git clone git://github.com/msanders/snipmate.vim.git
