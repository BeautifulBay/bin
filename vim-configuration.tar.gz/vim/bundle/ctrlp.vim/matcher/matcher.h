void score_list(char *abbrev,
                char **strs,
                int num_strs,
                int show_dotfiles,
                int limit);
